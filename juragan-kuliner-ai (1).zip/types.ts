
export interface AnalysisResult {
  content: string;
  sources: { title: string; uri: string }[];
  timestamp: string;
  dishName: string;
}

export interface HistoryItem {
  id: string;
  dishName: string;
  timestamp: string;
  result: AnalysisResult;
}
