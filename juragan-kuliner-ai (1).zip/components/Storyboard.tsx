
import React, { useState, useRef } from 'react';
import { generateVisualReference } from '../services/geminiService';

interface StoryboardProps {
  content: string;
  dishName: string;
}

export const Storyboard: React.FC<StoryboardProps> = ({ content, dishName }) => {
  const [visuals, setVisuals] = useState<Record<string, string>>({});
  const [generatingSteps, setGeneratingSteps] = useState<Record<string, boolean>>({});
  const [isGeneratingAll, setIsGeneratingAll] = useState(false);
  const cancelRef = useRef(false);

  const processInline = (str: string) => {
    let processed = str.trim();
    processed = processed.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    processed = processed.replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" class="text-indigo-600 hover:underline font-bold">$1</a>');
    return processed;
  };

  const extractShots = () => {
    const shots: { label: string; desc: string }[] = [];
    const lines = content.split('\n');
    lines.forEach(line => {
      if (line.includes('[SHOT-')) {
        const parts = line.split(']:');
        if (parts.length > 1) {
          const label = parts[0].replace('[', '').trim();
          const desc = parts[1].trim();
          shots.push({ label, desc });
        }
      }
    });
    return shots;
  };

  const shots = extractShots();
  const concept = content.match(/\[KONSEP\]: (.*)/)?.[1] || 'Modern Food Photography';

  const handleGenerateStep = async (label: string, desc: string) => {
    if (visuals[label]) return;
    setGeneratingSteps(prev => ({ ...prev, [label]: true }));
    try {
      const prompt = `${dishName}, ${concept} style, ${desc}`;
      const url = await generateVisualReference(prompt);
      if (url) {
        setVisuals(prev => ({ ...prev, [label]: url }));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setGeneratingSteps(prev => ({ ...prev, [label]: false }));
    }
  };

  const handleGenerateAll = async () => {
    setIsGeneratingAll(true);
    cancelRef.current = false;
    for (const shot of shots) {
      if (cancelRef.current) break;
      if (!visuals[shot.label]) {
        await handleGenerateStep(shot.label, shot.desc);
      }
    }
    setIsGeneratingAll(false);
  };

  const handleCancelAll = () => {
    cancelRef.current = true;
    setIsGeneratingAll(false);
  };

  if (shots.length === 0) return null;

  return (
    <div className="mt-12 bg-white rounded-3xl p-8 border border-slate-200 shadow-xl relative overflow-hidden">
      <div className="absolute top-0 right-0 p-8 flex flex-col items-end gap-2">
        {isGeneratingAll ? (
          <>
            <button 
              onClick={handleCancelAll}
              className="bg-red-50 text-red-600 border border-red-200 px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-red-600 hover:text-white transition-all shadow-sm"
            >
              <i className="fas fa-stop"></i> Berhenti Mengantre
            </button>
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest animate-pulse">
              Memproses satu per satu agar tidak limit...
            </span>
          </>
        ) : (
          <button 
            onClick={handleGenerateAll}
            disabled={shots.every(s => visuals[s.label])}
            className="bg-slate-900 text-white px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-orange-600 transition-all shadow-lg disabled:opacity-50 disabled:bg-slate-200 disabled:text-slate-400"
          >
            <i className="fas fa-wand-magic-sparkles"></i>
            Generate Semua Katalog
          </button>
        )}
      </div>

      <div className="mb-10">
        <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3 !mt-0 !mb-2 !before:hidden">
          <i className="fas fa-images text-orange-500"></i> Katalog Visual Per Step
        </h3>
        <p className="text-slate-500 max-w-xl leading-relaxed">
          Gaya: <span className="font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-lg">{concept}</span>. 
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {shots.map((shot, idx) => (
          <div key={idx} className="group bg-slate-50 rounded-2xl border border-slate-100 overflow-hidden hover:shadow-2xl transition-all duration-500 flex flex-col">
            <div className="relative aspect-square md:aspect-[4/3] bg-slate-200">
              {visuals[shot.label] ? (
                <img 
                  src={visuals[shot.label]} 
                  alt={shot.label} 
                  className="w-full h-full object-cover animate-in fade-in zoom-in duration-700" 
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-10 text-center">
                  <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center text-slate-300 text-2xl mb-4">
                    {generatingSteps[shot.label] ? <i className="fas fa-spinner animate-spin text-orange-500"></i> : <i className="fas fa-camera"></i>}
                  </div>
                  <p className="text-xs text-slate-400 font-medium mb-4">{shot.label}</p>
                  <button 
                    onClick={() => handleGenerateStep(shot.label, shot.desc)}
                    disabled={generatingSteps[shot.label]}
                    className="bg-white border border-slate-200 text-slate-800 px-5 py-2 rounded-xl text-xs font-black shadow-sm hover:border-orange-500 hover:text-orange-500 transition-all disabled:opacity-50"
                  >
                    {generatingSteps[shot.label] ? 'Sedang Mengantre...' : 'Buat Visual'}
                  </button>
                </div>
              )}
              {visuals[shot.label] && (
                <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-md text-white text-[10px] font-black px-3 py-1.5 rounded-full border border-white/20 uppercase tracking-widest">
                  {shot.label}
                </div>
              )}
            </div>
            <div className="p-6">
              <div 
                className="text-sm text-slate-700 leading-relaxed font-medium"
                dangerouslySetInnerHTML={{ __html: processInline(shot.desc) }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
