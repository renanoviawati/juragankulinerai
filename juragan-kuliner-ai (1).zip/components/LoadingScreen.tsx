
import React, { useState, useEffect } from 'react';

const messages = [
  "Sedang menyiapkan bahan baku...",
  "Menimbang gramasi resep...",
  "Mengecek harga pasar terbaru...",
  "Menyusun strategi konten visual...",
  "Menghitung kalkulasi HPP...",
  "Menghubungi supplier di Shopee...",
  "Hampir siap dihidangkan!"
];

interface LoadingScreenProps {
  onCancel?: () => void;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onCancel }) => {
  const [msgIndex, setMsgIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setMsgIndex((prev) => (prev + 1) % messages.length);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center py-20 animate-pulse">
      <div className="relative w-24 h-24 mb-8">
        <div className="absolute inset-0 border-4 border-orange-200 rounded-full"></div>
        <div className="absolute inset-0 border-4 border-orange-500 rounded-full border-t-transparent animate-spin"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <i className="fas fa-utensils text-3xl text-orange-500"></i>
        </div>
      </div>
      <h3 className="text-xl font-bold text-slate-800 mb-2">Juragan sedang memasak...</h3>
      <p className="text-slate-500 italic mb-6">{messages[msgIndex]}</p>
      
      {onCancel && (
        <button 
          onClick={onCancel}
          className="text-xs font-semibold text-slate-400 hover:text-slate-600 transition-colors flex items-center gap-2 border border-slate-200 px-4 py-2 rounded-full hover:bg-slate-50"
        >
          <i className="fas fa-times"></i> Batal Analisis
        </button>
      )}
    </div>
  );
};
