
import React from 'react';

interface BrandIdentityProps {
  content: string;
}

export const BrandIdentity: React.FC<BrandIdentityProps> = ({ content }) => {
  const extractColors = () => {
    const colors: { type: string; hex: string; desc: string }[] = [];
    const lines = content.split('\n');
    
    const types = ['Primary', 'Secondary', 'Accent', 'Background'];
    types.forEach(type => {
      const regex = new RegExp(`- \\*\\*${type}\\*\\*: (#?[A-Fa-f0-9]{6}) - (.*)`, 'i');
      const match = content.match(regex);
      if (match) {
        colors.push({ type, hex: match[1], desc: match[2] });
      }
    });
    return colors;
  };

  const colors = extractColors();
  if (colors.length === 0) return null;

  return (
    <div className="mt-12 bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
      <div className="flex items-center gap-3 mb-8">
        <div className="bg-emerald-500 text-white p-2 rounded-lg shadow-lg shadow-emerald-500/20">
          <i className="fas fa-palette"></i>
        </div>
        <div>
          <h3 className="text-xl font-bold text-slate-900 !mt-0 !mb-0 !before:hidden">Identitas Visual & Brand</h3>
          <p className="text-xs text-slate-500">Palet warna yang direkomendasikan untuk desain kemasan dan promosi.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {colors.map((color, idx) => (
          <div key={idx} className="bg-slate-50 rounded-2xl p-4 border border-slate-100 flex flex-col items-center text-center">
            <div 
              className="w-16 h-16 rounded-2xl shadow-inner mb-4 border border-black/5" 
              style={{ backgroundColor: color.hex.startsWith('#') ? color.hex : `#${color.hex}` }}
            ></div>
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">{color.type}</span>
            <code className="text-sm font-bold text-slate-800 mb-2">{color.hex.startsWith('#') ? color.hex : `#${color.hex}`}</code>
            <p className="text-[10px] text-slate-500 leading-relaxed italic">"{color.desc}"</p>
          </div>
        ))}
      </div>
    </div>
  );
};
