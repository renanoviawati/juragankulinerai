
import React, { useState, useRef } from 'react';
import { generateVisualReference } from '../services/geminiService';

interface InstagramPreviewProps {
  content: string;
  dishName: string;
}

export const InstagramPreview: React.FC<InstagramPreviewProps> = ({ content, dishName }) => {
  const [visuals, setVisuals] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState<Record<string, boolean>>({});
  const abortControllersRef = useRef<Record<string, AbortController>>({});

  const extractCaptions = () => {
    const captions: string[] = [];
    const match1 = content.match(/\[CAPTION-1\]:? (.*)/i);
    const match2 = content.match(/\[CAPTION-2\]:? (.*)/i);
    const match3 = content.match(/\[CAPTION-3\]:? (.*)/i);
    if (match1) captions.push(match1[1]);
    if (match2) captions.push(match2[1]);
    if (match3) captions.push(match3[1]);
    return captions;
  };

  const captions = extractCaptions();

  const handleGenerate = async (idx: number, caption: string) => {
    const key = `post-${idx}`;
    if (visuals[key]) return;
    
    setLoading(prev => ({ ...prev, [key]: true }));
    const controller = new AbortController();
    abortControllersRef.current[key] = controller;
    
    try {
      const prompt = `Instagram feed post for ${dishName}: ${caption}. High quality, cinematic lighting.`;
      const url = await generateVisualReference(prompt, 0, controller.signal);
      if (url) setVisuals(prev => ({ ...prev, [key]: url }));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(prev => ({ ...prev, [key]: false }));
      delete abortControllersRef.current[key];
    }
  };

  const handleCancel = (idx: number) => {
    const key = `post-${idx}`;
    if (abortControllersRef.current[key]) {
      abortControllersRef.current[key].abort();
      setLoading(prev => ({ ...prev, [key]: false }));
    }
  };

  if (captions.length === 0) return null;

  return (
    <div className="mt-12 bg-slate-900 rounded-3xl p-8 md:p-12 text-white overflow-hidden relative">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500"></div>
      
      <div className="flex flex-col md:flex-row gap-12 items-start relative z-10">
        {/* Mockup Instagram */}
        <div className="w-full md:w-80 flex-shrink-0">
          <div className="bg-black rounded-[3rem] p-3 border-[6px] border-slate-800 shadow-2xl aspect-[9/19] relative overflow-hidden">
            <div className="bg-white h-full w-full rounded-[2.2rem] overflow-hidden flex flex-col text-slate-900">
              {/* Header IG */}
              <div className="px-4 py-3 border-b flex items-center justify-between">
                <span className="text-[10px] font-bold">@juragankuliner</span>
                <i className="fas fa-ellipsis-h text-xs"></i>
              </div>
              
              {/* Grid Preview */}
              <div className="flex-1 overflow-y-auto">
                <div className="grid grid-cols-3 gap-[1px] bg-slate-200">
                  {[...Array(9)].map((_, i) => (
                    <div key={i} className="aspect-square bg-white relative group">
                      {visuals[`post-${i%3}`] ? (
                        <img src={visuals[`post-${i%3}`]} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-[10px] text-slate-300">
                          {i < 3 ? (
                            <button onClick={() => loading[`post-${i}`] ? handleCancel(i) : handleGenerate(i, captions[i])}>
                              {loading[`post-${i}`] ? <i className="fas fa-spinner animate-spin text-orange-500"></i> : <i className="fas fa-plus"></i>}
                            </button>
                          ) : <i className="fas fa-image"></i>}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                {/* Stats */}
                <div className="p-4 flex gap-4 text-xs font-bold border-t">
                  <div className="text-center flex-1">
                    <div className="block">12</div>
                    <div className="text-[8px] text-slate-400 font-normal uppercase">Posts</div>
                  </div>
                  <div className="text-center flex-1">
                    <div className="block">1.2k</div>
                    <div className="text-[8px] text-slate-400 font-normal uppercase">Followers</div>
                  </div>
                  <div className="text-center flex-1">
                    <div className="block">340</div>
                    <div className="text-[8px] text-slate-400 font-normal uppercase">Following</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Caption Strategy */}
        <div className="flex-1 space-y-6">
          <div className="mb-4">
            <h3 className="text-2xl font-black text-white mb-2 !before:hidden">Strategi Feed Instagram</h3>
            <p className="text-slate-400 text-sm">Gunakan caption ini untuk meningkatkan engagement pelanggan Anda.</p>
          </div>

          {captions.map((cap, i) => (
            <div key={i} className="bg-white/5 border border-white/10 p-5 rounded-2xl hover:bg-white/10 transition-colors group">
              <div className="flex justify-between items-center mb-3">
                <span className="text-[10px] font-black text-pink-400 uppercase tracking-widest">Postingan Ke-{i+1}</span>
                {!visuals[`post-${i}`] && (
                  loading[`post-${i}`] ? (
                    <button 
                      onClick={() => handleCancel(i)}
                      className="text-[10px] bg-red-500 text-white px-3 py-1 rounded-full font-bold hover:bg-red-600 transition-all"
                    >
                      Batal Visual
                    </button>
                  ) : (
                    <button 
                      onClick={() => handleGenerate(i, cap)}
                      className="text-[10px] bg-white text-slate-900 px-3 py-1 rounded-full font-bold hover:bg-pink-500 hover:text-white transition-all"
                    >
                      Buat Preview Foto
                    </button>
                  )
                )}
              </div>
              <p className="text-sm text-slate-300 leading-relaxed italic">"{cap}"</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
