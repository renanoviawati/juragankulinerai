
import React, { useState, useRef } from 'react';
import { generateVisualReference } from '../services/geminiService';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const [stepImages, setStepImages] = useState<Record<string, string>>({});
  const [loadingSteps, setLoadingSteps] = useState<Record<string, boolean>>({});
  const [isBulkLoading, setIsBulkLoading] = useState<Record<string, boolean>>({});
  const bulkCancelRef = useRef(false);

  const handleVisualizeStep = async (text: string, id: string) => {
    if (stepImages[id]) return;
    setLoadingSteps(prev => ({ ...prev, [id]: true }));
    try {
      const url = await generateVisualReference(`Step by step cooking guide: ${text}`);
      if (url) {
        setStepImages(prev => ({ ...prev, [id]: url }));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingSteps(prev => ({ ...prev, [id]: false }));
    }
  };

  const handleVisualizeAllInList = async (items: string[], listKey: string) => {
    setIsBulkLoading(prev => ({ ...prev, [listKey]: true }));
    bulkCancelRef.current = false;
    for (let i = 0; i < items.length; i++) {
      if (bulkCancelRef.current) break;
      const itemId = `step-${listKey}-${i}`;
      if (!stepImages[itemId]) {
        await handleVisualizeStep(items[i], itemId);
      }
    }
    setIsBulkLoading(prev => ({ ...prev, [listKey]: false }));
  };

  const handleCancelBulk = (listKey: string) => {
    bulkCancelRef.current = true;
    setIsBulkLoading(prev => ({ ...prev, [listKey]: false }));
  };

  const processInline = (str: string) => {
    let processed = str.trim();
    // Bold
    processed = processed.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    // Links (Shopee)
    processed = processed.replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" class="text-orange-500 hover:underline font-bold inline-flex items-center gap-1"><i class="fas fa-shopping-bag text-[10px]"></i>$1</a>');
    return processed;
  };

  const isNumeric = (str: string) => {
    const clean = str.replace(/Rp|\.|\s|,/g, '').replace(/<strong>|<\/strong>/g, '');
    return !isNaN(parseFloat(clean)) || str.toLowerCase().includes('rp');
  };

  const parseMarkdown = (text: string) => {
    const lines = text.split('\n');
    const finalElements: React.ReactNode[] = [];
    
    let inTable = false;
    let tableRows: string[][] = [];
    let listItems: string[] = [];
    let inList = false;

    const flushList = (key: string) => {
      if (listItems.length > 0) {
        const currentItems = [...listItems];
        finalElements.push(
          <div key={`list-${key}`} className="mb-8 relative">
            <div className="flex justify-between items-center mb-4">
              <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">Detail Langkah SOP</h4>
              <div className="flex gap-2">
                {isBulkLoading[key] ? (
                  <button 
                    onClick={() => handleCancelBulk(key)}
                    className="text-[10px] bg-red-50 text-red-600 px-3 py-1 rounded-full font-bold border border-red-100 hover:bg-red-600 hover:text-white transition-all"
                  >
                    <i className="fas fa-stop mr-1"></i> Batal Visualisasi
                  </button>
                ) : (
                  <button 
                    onClick={() => handleVisualizeAllInList(currentItems, key)}
                    className="text-[10px] bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full font-bold border border-indigo-100 hover:bg-indigo-600 hover:text-white transition-all disabled:opacity-50"
                  >
                    <i className="fas fa-magic mr-1"></i> Visualisasikan Semua Langkah
                  </button>
                )}
              </div>
            </div>
            <ul className="space-y-6">
              {currentItems.map((item, i) => {
                const itemId = `step-${key}-${i}`;
                return (
                  <li key={i} className="group">
                    <div className="flex justify-between items-start gap-4">
                      <div className="flex gap-3 flex-1">
                        <span className="flex-shrink-0 w-6 h-6 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center text-[10px] font-black mt-0.5 border border-orange-200">
                          {i + 1}
                        </span>
                        <span className="text-slate-700 leading-relaxed" dangerouslySetInnerHTML={{ __html: processInline(item) }} />
                      </div>
                      <button 
                        onClick={() => handleVisualizeStep(item, itemId)}
                        disabled={loadingSteps[itemId]}
                        className={`shrink-0 w-9 h-9 rounded-xl flex items-center justify-center text-xs border transition-all ${stepImages[itemId] ? 'bg-emerald-50 border-emerald-200 text-emerald-600' : 'bg-slate-50 border-slate-200 text-slate-400 hover:border-orange-500 hover:text-orange-500 hover:bg-white'}`}
                      >
                        {loadingSteps[itemId] ? <i className="fas fa-spinner animate-spin"></i> : <i className="fas fa-camera"></i>}
                      </button>
                    </div>
                    {stepImages[itemId] && (
                      <div className="mt-4 ml-9 rounded-2xl overflow-hidden border border-slate-200 shadow-lg max-w-lg animate-in fade-in slide-in-from-top-4 duration-700 group">
                        <img src={stepImages[itemId]} className="w-full h-auto" />
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          </div>
        );
        listItems = [];
        inList = false;
      }
    };

    const flushTable = (key: string) => {
      if (tableRows.length > 0) {
        const displayRows = tableRows.filter(row => !row.join('').includes('---'));
        if (displayRows.length > 0) {
          const header = displayRows[0];
          const body = displayRows.slice(1);
          finalElements.push(
            <div key={`table-wrapper-${key}`} className="overflow-x-auto my-8 shadow-md border border-slate-200 rounded-2xl bg-white">
              <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr>
                    {header.map((cell, i) => (
                      <th 
                        key={i} 
                        className={`px-5 py-4 text-[10px] font-black text-slate-500 uppercase tracking-widest ${isNumeric(cell) ? 'text-right' : 'text-left'}`}
                        dangerouslySetInnerHTML={{ __html: processInline(cell) }}
                      />
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-100">
                  {body.map((row, i) => {
                    const isTotalRow = row.some(cell => cell.toLowerCase().includes('total') || cell.toLowerCase().includes('rekomendasi'));
                    return (
                      <tr key={i} className={`${isTotalRow ? 'bg-orange-50/50 font-bold' : 'hover:bg-slate-50/50 transition-colors'}`}>
                        {row.map((cell, j) => (
                          <td 
                            key={j} 
                            className={`px-5 py-4 text-sm text-slate-600 ${isNumeric(cell) ? 'text-right font-mono' : 'text-left'}`}
                            dangerouslySetInnerHTML={{ __html: processInline(cell) }}
                          />
                        ))}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <div className="bg-slate-50 px-5 py-3 text-[9px] text-slate-400 italic">
                * Estimasi HPP dapat berubah sesuai harga pasar lokal.
              </div>
            </div>
          );
        }
        tableRows = [];
        inTable = false;
      }
    };

    lines.forEach((line, index) => {
      const trimmedLine = line.trim();
      
      if (trimmedLine.startsWith('|')) {
        flushList(`before-table-${index}`);
        inTable = true;
        const cells = line.split('|').map(c => c.trim()).filter((c, i, arr) => !(i === 0 && c === '') && !(i === arr.length - 1 && c === ''));
        if (cells.length > 0) tableRows.push(cells);
        return;
      } else if (inTable) {
        flushTable(`end-table-${index}`);
      }

      if (trimmedLine.startsWith('* ') || trimmedLine.startsWith('- ') || /^\d+\.\s/.test(trimmedLine)) {
        inList = true;
        listItems.push(trimmedLine.replace(/^(\*|-|\d+\.)\s/, ''));
        return;
      } else if (inList) {
        flushList(`end-list-${index}`);
      }

      if (trimmedLine.startsWith('### ')) {
        finalElements.push(<h3 key={index} dangerouslySetInnerHTML={{ __html: processInline(trimmedLine.substring(4)) }} />);
        return;
      }

      if (trimmedLine === '') {
        finalElements.push(<div key={`br-${index}`} className="h-2"></div>);
      } else {
        finalElements.push(<p key={index} className="mb-4 text-slate-600 leading-relaxed" dangerouslySetInnerHTML={{ __html: processInline(trimmedLine) }} />);
      }
    });

    flushTable('final');
    flushList('final');
    return finalElements;
  };

  return (
    <div className="markdown-content text-slate-700 leading-relaxed">
      {parseMarkdown(content)}
    </div>
  );
};
