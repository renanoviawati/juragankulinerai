
import React from 'react';

interface MarketingKitProps {
  content: string;
}

export const MarketingKit: React.FC<MarketingKitProps> = ({ content }) => {
  const processInline = (str: string) => {
    let processed = str.trim();
    // Bold
    processed = processed.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    // Links (Shopee)
    processed = processed.replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" class="text-orange-600 hover:underline font-bold inline-flex items-center gap-1"><i class="fas fa-shopping-bag text-[10px]"></i>$1</a>');
    return processed;
  };

  const extractAIDA = () => {
    const aida = {
      attention: content.match(/\[ATTENTION\]: (.*)/)?.[1] || '',
      interest: content.match(/\[INTEREST\]: (.*)/)?.[1] || '',
      desire: content.match(/\[DESIRE\]: (.*)/)?.[1] || '',
      action: content.match(/\[ACTION\]: (.*)/)?.[1] || '',
    };
    return aida;
  };

  const aida = extractAIDA();
  if (!aida.attention && !aida.interest) return null;

  const steps = [
    { label: 'Attention', icon: 'fa-bullhorn', color: 'bg-rose-500', text: aida.attention, desc: 'Tarik Perhatian' },
    { label: 'Interest', icon: 'fa-lightbulb', color: 'bg-indigo-500', text: aida.interest, desc: 'Bangun Ketertarikan' },
    { label: 'Desire', icon: 'fa-heart', color: 'bg-purple-500', text: aida.desire, desc: 'Ciptakan Keinginan' },
    { label: 'Action', icon: 'fa-shopping-cart', color: 'bg-emerald-500', text: aida.action, desc: 'Dorong Pembelian' },
  ];

  return (
    <div className="mt-10 mb-8 overflow-hidden">
      <div className="flex items-center gap-2 mb-6">
        <div className="bg-indigo-600 text-white p-2 rounded-lg shadow-lg">
          <i className="fas fa-rocket"></i>
        </div>
        <div>
          <h3 className="text-xl font-bold text-slate-900">Marketing Kit (AIDA)</h3>
          <p className="text-sm text-slate-500">Strategi promosi otomatis hasil racikan Juragan.</p>
        </div>
      </div>

      <div className="space-y-4">
        {steps.map((step, idx) => (
          <div key={idx} className="group relative flex gap-6 bg-white border border-slate-100 p-6 rounded-2xl shadow-sm hover:shadow-md transition-all hover:border-indigo-100">
            {idx < steps.length - 1 && (
              <div className="absolute left-[2.25rem] top-16 bottom-0 w-0.5 bg-slate-100 group-hover:bg-indigo-50"></div>
            )}
            <div className={`flex-shrink-0 w-12 h-12 ${step.color} text-white rounded-xl flex items-center justify-center text-xl shadow-lg shadow-current/20 z-10`}>
              <i className={`fas ${step.icon}`}></i>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">{step.label}</span>
                <span className="h-px flex-1 bg-slate-50"></span>
              </div>
              <h4 className="text-lg font-bold text-slate-800 mb-2">{step.desc}</h4>
              <p 
                className="text-slate-600 leading-relaxed italic bg-slate-50/50 p-4 rounded-xl border border-dashed border-slate-200"
                dangerouslySetInnerHTML={{ __html: `"${processInline(step.text)}"` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
