
import React, { useState, useRef } from 'react';
import { generateVisualReference } from '../services/geminiService';

interface MainVisualProps {
  dishName: string;
  concept?: string;
}

export const MainVisual: React.FC<MainVisualProps> = ({ dishName, concept }) => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  const handleGenerate = async () => {
    setLoading(true);
    abortControllerRef.current = new AbortController();
    try {
      const prompt = `${dishName}, ${concept || 'Professional food photography'}, cinematic lighting, high resolution, appetizing, masterchef plating`;
      const result = await generateVisualReference(prompt, 0, abortControllerRef.current.signal);
      if (result) setImageUrl(result);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setLoading(false);
  };

  return (
    <div className="mb-10 group">
      {!imageUrl ? (
        <div className="w-full aspect-[21/9] bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center justify-center gap-3 relative overflow-hidden">
          {loading ? (
            <div className="flex flex-col items-center gap-4 animate-in fade-in">
              <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center text-orange-500 text-2xl">
                <i className="fas fa-spinner animate-spin"></i>
              </div>
              <button 
                onClick={handleCancel}
                className="bg-red-50 text-red-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border border-red-100 hover:bg-red-600 hover:text-white transition-all"
              >
                <i className="fas fa-times mr-1"></i> Batal Visual
              </button>
            </div>
          ) : (
            <button 
              onClick={handleGenerate}
              className="flex flex-col items-center gap-3 w-full h-full justify-center group-hover:bg-orange-50 transition-all"
            >
              <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center text-orange-500 text-2xl group-hover:scale-110 transition-transform">
                <i className="fas fa-wand-magic-sparkles"></i>
              </div>
              <div className="text-center">
                <span className="block font-bold text-slate-700">Visualisasikan Menu Jadi</span>
                <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest flex items-center justify-center gap-1">
                  <i className="fas fa-check-circle"></i> Gratis via Free Tier
                </span>
              </div>
            </button>
          )}
        </div>
      ) : (
        <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-orange-900/10 border border-slate-200 animate-in fade-in zoom-in-95 duration-500">
          <img src={imageUrl} alt={dishName} className="w-full aspect-[21/9] object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-8">
            <div className="w-full flex justify-between items-end">
              <div>
                <span className="text-orange-400 text-xs font-bold uppercase tracking-widest mb-1 block">Referensi Visual Utama</span>
                <h3 className="text-2xl font-black text-white">{dishName}</h3>
              </div>
              <button 
                onClick={handleGenerate}
                className="bg-white/20 backdrop-blur-md hover:bg-white/40 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all"
              >
                <i className="fas fa-redo mr-2"></i> Ganti Visual
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
