
import { GoogleGenAI } from "@google/genai";

const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

// Antrean Global untuk Image Generation
let imageRequestQueue: Promise<any> = Promise.resolve();
const MIN_IMAGE_DELAY = 2500; // Jeda 2.5 detik antar request sukses
const ERROR_RETRY_DELAY = 6000; // Jeda 6 detik jika kena limit

const SYSTEM_PROMPT = `Anda adalah "Juragan Kuliner AI", konsultan F&B profesional. Tugas Anda adalah menyusun SOP, link belanja, strategi visual, dan analisis profitabilitas yang akurat.

STRUKTUR OUTPUT (WAJIB):

### 1. Resep Standar & Daftar Belanja (SOP)
- **Bahan Baku**: List gramasi presisi + Link Shopee.
- **Peralatan**: List alat + Link Shopee.
- **Langkah Pembuatan**: Instruksi deskriptif visual dengan penomoran (1., 2., dst).
- **FORMAT LINK**: [Nama Produk - Klik untuk Beli](https://shopee.co.id/search?keyword=nama+produk).

### 2. Panduan Foto Katalog (Storyboard)
[KONSEP]: (Gaya visual)
[SHOT-1] s/d [SHOT-4]: (Deskripsi visual detail)

### 3. Marketing Kit (AIDA)
[ATTENTION], [INTEREST], [DESIRE], [ACTION]: (Copywriting kreatif)

### 4. Analisis HPP & Profitabilitas
| No | Item Bahan | Satuan | Harga Satuan | Qty/Resep | Subtotal |
|---|---|---|---|---|---|
| ... | ... | ... | ... | ... | ... |
| | **TOTAL HPP PER PORSI** | | | | **Rp [Total]** |
| | **Margin Keuntungan (60%)** | | | | **Rp [Margin]** |
| | **Rekomendasi Harga Jual** | | | | **Rp [Harga]** |

### 5. Identitas Brand & Palet Warna
- **Primary**: (Hex Code) - (Alasan Psikologi)
- **Secondary**: (Hex Code) - (Kegunaan)
- **Accent**: (Hex Code) - (Kegunaan)
- **Background**: (Hex Code)

### 6. Strategi Instagram Feed (3x3 Grid)
- **Post 1**: (Tema) + [CAPTION-1]
- **Post 2**: (Tema) + [CAPTION-2]
- **Post 3**: (Tema) + [CAPTION-3]

PENTING: Gunakan Bahasa Indonesia. HPP harus realistis pasar Indonesia.`;

export const analyzeDish = async (dishName: string, retryCount = 0): Promise<any> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview", 
      contents: `Buatkan analisis bisnis kuliner lengkap untuk menu: ${dishName}. Fokuskan pada perhitungan HPP yang akurat.`,
      config: { systemInstruction: SYSTEM_PROMPT },
    });
    return {
      content: response.text || "Maaf, terjadi kesalahan.",
      sources: [],
      timestamp: new Date().toLocaleString('id-ID'),
      dishName
    };
  } catch (error: any) {
    if (error.message?.includes("429") && retryCount < 3) {
      await delay(Math.pow(2, retryCount) * 2000);
      return analyzeDish(dishName, retryCount + 1);
    }
    throw error;
  }
};

/**
 * Fungsi generateVisualReference dengan antrean global untuk menghindari 429 RESOURCE_EXHAUSTED
 */
export const generateVisualReference = async (prompt: string, retryCount = 0, signal?: AbortSignal): Promise<string | null> => {
  if (signal?.aborted) return null;

  // Bungkus dalam antrean agar tidak terjadi request simultan
  const result = await (imageRequestQueue = imageRequestQueue.then(async () => {
    if (signal?.aborted) return null;
    
    // Berikan jeda napas antar request sukses agar tidak dianggap spam oleh server
    await delay(MIN_IMAGE_DELAY);

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [{ text: `Commercial food photography, ${prompt}, ultra realistic, appetizing.` }]
        },
        config: { imageConfig: { aspectRatio: "1:1" } }
      });

      if (signal?.aborted) return null;

      const imagePart = response.candidates[0].content.parts.find(p => p.inlineData);
      return imagePart ? `data:image/png;base64,${imagePart.inlineData.data}` : null;

    } catch (error: any) {
      console.warn("Queue Image Error:", error.message);

      // Jika terkena limit (429), lakukan retry dengan jeda lebih lama
      if (error.message?.includes("429") && retryCount < 2 && !signal?.aborted) {
        console.log(`Quota hit. Waiting ${ERROR_RETRY_DELAY}ms for retry ${retryCount + 1}...`);
        await delay(ERROR_RETRY_DELAY);
        return generateVisualReference(prompt, retryCount + 1, signal);
      }
      return null;
    }
  }));

  return result;
};
