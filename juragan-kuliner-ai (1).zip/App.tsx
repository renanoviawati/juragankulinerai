
import React, { useState, useEffect, useRef } from 'react';
import { analyzeDish } from './services/geminiService';
import { AnalysisResult, HistoryItem } from './types';
import { LoadingScreen } from './components/LoadingScreen';
import { MarkdownRenderer } from './components/MarkdownRenderer';
import { Storyboard } from './components/Storyboard';
import { MarketingKit } from './components/MarketingKit';
import { MainVisual } from './components/MainVisual';
import { BrandIdentity } from './components/BrandIdentity';
import { InstagramPreview } from './components/InstagramPreview';
// @ts-ignore
import { jsPDF } from 'jspdf';
// @ts-ignore
import html2canvas from 'html2canvas';

const App: React.FC = () => {
  const [input, setInput] = useState('');
  const [lastInput, setLastInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isLaunched, setIsLaunched] = useState(false);
  const [showDeployGuide, setShowDeployGuide] = useState(false);
  
  const cancelRequest = useRef(false);
  const resultRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem('jk_history');
    if (saved) {
      setHistory(JSON.parse(saved));
    }
  }, []);

  const handleLaunch = () => {
    setIsLaunched(true);
  };

  const handleAnalyze = async (e?: React.FormEvent, customInput?: string) => {
    if (e) e.preventDefault();
    const query = (customInput || input).trim();
    if (!query) return;

    const cachedItem = history.find(item => item.dishName.toLowerCase() === query.toLowerCase());
    if (cachedItem && !customInput) {
      setResult(cachedItem.result);
      setLastInput(cachedItem.dishName);
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);
    setLastInput(query);
    cancelRequest.current = false;

    try {
      const data = await analyzeDish(query);
      if (cancelRequest.current) return;
      setResult(data);
      
      const newHistoryItem: HistoryItem = {
        id: Date.now().toString(),
        dishName: query,
        timestamp: data.timestamp,
        result: data
      };

      const updatedHistory = [newHistoryItem, ...history.filter(h => h.dishName.toLowerCase() !== query.toLowerCase()).slice(0, 9)];
      setHistory(updatedHistory);
      localStorage.setItem('jk_history', JSON.stringify(updatedHistory));
      if (!customInput) setInput('');
    } catch (err: any) {
      if (!cancelRequest.current) {
        if (err.message?.includes("429")) {
          setError("Limit Free Tier Tercapai. Mohon tunggu 60 detik sebelum mencoba menu baru.");
        } else if (err.message?.includes("Requested entity was not found")) {
          setError("Fitur ini membutuhkan API Key yang valid. Silakan hubungkan kunci Anda.");
          // @ts-ignore
          if (window.aistudio) window.aistudio.openSelectKey();
        } else {
          setError("Gagal menghubungi Juragan Kuliner. Coba lagi dalam beberapa saat.");
        }
      }
      console.error(err);
    } finally {
      if (!cancelRequest.current) {
        setLoading(false);
      }
    }
  };

  const handleDownloadPDF = async () => {
    if (!resultRef.current || !result) return;
    
    setExporting(true);
    try {
      const actionElements = document.querySelectorAll('button, .no-print');
      actionElements.forEach(el => (el as HTMLElement).style.opacity = '0');

      const canvas = await html2canvas(resultRef.current, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
      
      const finalWidth = imgWidth * ratio;
      const finalHeight = imgHeight * ratio;
      
      pdf.addImage(imgData, 'PNG', 0, 0, finalWidth, finalHeight);
      pdf.save(`${result.dishName.replace(/\s+/g, '_')}_Cetak_Biru_Juragan.pdf`);

      actionElements.forEach(el => (el as HTMLElement).style.opacity = '1');
    } catch (err) {
      console.error("Gagal mengunduh PDF:", err);
      alert("Terjadi kesalahan saat membuat PDF. Silakan coba cetak halaman ini secara manual.");
    } finally {
      setExporting(false);
    }
  };

  const handleCancel = () => {
    cancelRequest.current = true;
    setLoading(false);
    setError(null);
  };

  const loadFromHistory = (item: HistoryItem) => {
    setResult(item.result);
    setLastInput(item.dishName);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const copyEnvKey = () => {
    navigator.clipboard.writeText("API_KEY");
    alert("Nama variabel 'API_KEY' berhasil disalin!");
  };

  if (!isLaunched) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl p-10 text-center border border-slate-100">
          <div className="bg-orange-500 w-20 h-20 rounded-2xl flex items-center justify-center text-white text-4xl mx-auto mb-6 shadow-lg shadow-orange-500/30">
            <i className="fas fa-store"></i>
          </div>
          <h1 className="text-3xl font-black text-slate-900 mb-3">Juragan Kuliner AI</h1>
          <p className="text-slate-500 mb-8 leading-relaxed">
            Asisten cerdas untuk SOP dapur, strategi visual katalog, marketing AIDA, dan kalkulasi HPP.
          </p>
          <div className="flex justify-center gap-2 mb-8">
            <span className="bg-emerald-50 text-emerald-600 text-[10px] font-bold px-3 py-1 rounded-full border border-emerald-100 uppercase tracking-wider">
              <i className="fas fa-bolt mr-1"></i> Versi Free Tier Aktif
            </span>
          </div>
          <button 
            onClick={handleLaunch}
            className="w-full bg-slate-900 hover:bg-slate-800 text-white py-4 rounded-xl font-bold text-lg transition-all active:scale-95 shadow-xl shadow-slate-900/20"
          >
            Mulai Konsultasi Gratis <i className="fas fa-arrow-right ml-2"></i>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20 animate-in fade-in duration-700">
      <header className="bg-white border-b sticky top-0 z-30 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-orange-500 text-white p-2 rounded-lg">
              <i className="fas fa-utensils text-xl"></i>
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 leading-tight">Juragan Kuliner</h1>
              <div className="flex items-center gap-2">
                <p className="text-[10px] text-emerald-600 font-black uppercase tracking-widest">Free Mode</p>
                <div className="group relative">
                  <i className="fas fa-info-circle text-[10px] text-slate-400 cursor-help"></i>
                  <div className="absolute left-0 top-full mt-2 w-48 bg-slate-800 text-white text-[10px] p-2 rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50 shadow-xl">
                    Free tier terbatas 15 request/menit. Jika error, tunggu 60 detik.
                  </div>
                </div>
              </div>
            </div>
          </div>
          {error && (
            <div className="hidden md:block text-xs text-red-500 font-bold bg-red-50 px-3 py-1 rounded-full border border-red-100 animate-pulse">
              <i className="fas fa-exclamation-circle mr-1"></i> {error}
            </div>
          )}
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        <section className="bg-slate-900 rounded-3xl p-8 md:p-12 mb-10 text-white shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
          <div className="relative z-10">
            <div className="flex flex-wrap items-center gap-2 mb-4">
               <h2 className="text-3xl md:text-4xl font-black">Cetak Biru Bisnis F&B</h2>
               <span className="bg-orange-500/20 text-orange-400 text-[10px] font-bold px-2 py-1 rounded border border-orange-500/30">AI ASSISTED</span>
            </div>
            <p className="text-slate-400 mb-8 max-w-xl">Input nama menu, Juragan buatkan SOP, Link Belanja Shopee, hingga Foto Katalog dalam hitungan detik.</p>
            <form onSubmit={handleAnalyze} className="flex flex-col md:flex-row gap-3">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Misal: Es Kopi Susu Gula Aren..." 
                className="flex-1 px-6 py-4 rounded-2xl bg-white text-slate-900 text-lg font-medium focus:ring-4 focus:ring-orange-500/20 outline-none transition-all"
                disabled={loading}
              />
              <button 
                type="submit"
                disabled={loading || !input.trim()}
                className="bg-orange-500 hover:bg-orange-600 text-white px-10 py-4 rounded-2xl font-black text-lg transition-all flex items-center justify-center gap-2 shadow-lg shadow-orange-500/30 disabled:bg-slate-700"
              >
                {loading ? <i className="fas fa-spinner animate-spin"></i> : <i className="fas fa-magic"></i>}
                Riset Menu
              </button>
            </form>
          </div>
        </section>

        {error && (
          <div className="mb-8 bg-red-50 border border-red-100 p-4 rounded-2xl flex items-center gap-3 text-red-700 text-sm animate-in slide-in-from-top-2">
            <i className="fas fa-exclamation-triangle flex-shrink-0"></i>
            <p className="font-medium">{error}</p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <aside className="lg:col-span-3 space-y-4">
            <div className="bg-white rounded-2xl border border-slate-200 p-5">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Riwayat Riset</h3>
              {history.length === 0 ? (
                <p className="text-xs text-slate-400 italic">Belum ada riwayat.</p>
              ) : (
                <div className="flex flex-col gap-2">
                  {history.map((item) => (
                    <button key={item.id} onClick={() => loadFromHistory(item)} className={`text-left p-3 rounded-xl text-sm transition-all border ${result?.dishName === item.dishName ? 'bg-orange-50 border-orange-200 text-orange-700 font-bold' : 'bg-slate-50 border-transparent text-slate-600 hover:bg-slate-100'}`}>
                      {item.dishName}
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            <div className="bg-indigo-50 rounded-2xl p-5 border border-indigo-100">
              <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                <i className="fas fa-info-circle"></i> Info Kuota & Reset
              </h4>
              <div className="space-y-4">
                <div>
                  <p className="text-[10px] text-indigo-700 font-bold mb-1 uppercase tracking-tight">Batas Menit (RPM)</p>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-slate-900">15 Request</span>
                    <span className="text-[9px] bg-white px-1.5 py-0.5 rounded border border-indigo-200 text-indigo-500">60dtk</span>
                  </div>
                </div>
                <div>
                  <p className="text-[10px] text-indigo-700 font-bold mb-1 uppercase tracking-tight">Batas Harian (RPD)</p>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-slate-900">1.500 Request</span>
                    <span className="text-[9px] bg-white px-1.5 py-0.5 rounded border border-indigo-200 text-indigo-500">14:00 WIB</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-slate-900 rounded-2xl p-5 border border-slate-700 text-white">
              <h4 className="text-[10px] font-black text-orange-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                <i className="fas fa-rocket"></i> Panduan Deploy
              </h4>
              <ol className="text-[9px] space-y-2 text-slate-300 list-decimal pl-4">
                <li>Buka <span className="text-white font-bold">Vercel.com</span> atau <span className="text-white font-bold">Netlify</span>.</li>
                <li>Hubungkan dengan akun GitHub Juragan.</li>
                <li>Cari bagian <span className="text-orange-300 italic">Environment Variables</span>.</li>
                <li>Masukkan <button onClick={copyEnvKey} className="text-white font-mono bg-white/10 px-1 rounded hover:bg-white/20 transition-all">API_KEY</button> sebagai Key.</li>
                <li>Tempelkan kunci Gemini Juragan sebagai Value.</li>
              </ol>
              <p className="text-[8px] mt-4 text-slate-500 italic">
                * Aplikasi akan online gratis selamanya.
              </p>
            </div>

            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Tips Juragan</h4>
              <p className="text-[10px] text-slate-500 leading-relaxed italic">
                "Gunakan visualisasi hanya untuk menu yang sudah fiks agar kuota harian tidak cepat habis."
              </p>
            </div>
          </aside>

          <div className="lg:col-span-9">
            {loading && <LoadingScreen onCancel={handleCancel} />}
            {result && !loading && (
              <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-8">
                <div ref={resultRef} className="bg-white rounded-3xl border border-slate-200 p-8 md:p-12 shadow-sm">
                  <div className="flex flex-col md:flex-row justify-between items-start mb-8 gap-4">
                    <div>
                      <h2 className="text-4xl font-black text-slate-900 mb-2">{result.dishName}</h2>
                      <p className="text-sm text-slate-400 flex items-center gap-2">
                        <i className="fas fa-clock"></i> Analisis Selesai: {result.timestamp}
                      </p>
                    </div>
                    <button 
                      onClick={handleDownloadPDF}
                      disabled={exporting}
                      className="no-print bg-slate-900 hover:bg-orange-600 text-white px-6 py-3 rounded-2xl font-bold text-sm transition-all flex items-center gap-2 shadow-xl shadow-slate-900/10 disabled:opacity-50"
                    >
                      {exporting ? <i className="fas fa-spinner animate-spin"></i> : <i className="fas fa-file-pdf"></i>}
                      {exporting ? "Menyiapkan PDF..." : "Unduh Cetak Biru (PDF)"}
                    </button>
                  </div>

                  <MainVisual dishName={result.dishName} concept={result.content.match(/\[KONSEP\]: (.*)/)?.[1]} />
                  
                  <MarkdownRenderer content={result.content} />
                  
                  <BrandIdentity content={result.content} />
                  <InstagramPreview content={result.content} dishName={result.dishName} />
                  
                  <Storyboard content={result.content} dishName={result.dishName} />
                  <MarketingKit content={result.content} />
                  
                  <div className="mt-12 pt-8 border-t border-slate-100 text-center text-[10px] text-slate-400 font-medium no-print">
                    <p>© 2024 Juragan Kuliner AI - Konsultan F&B Digital Anda</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
